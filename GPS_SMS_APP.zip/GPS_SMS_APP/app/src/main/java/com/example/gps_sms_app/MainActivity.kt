package com.example.gps_sms_app
import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices

class MainActivity : AppCompatActivity() {
    private lateinit var btnSend: Button
    private lateinit var messageSMS: String
    private lateinit var phoneNumberEditText: EditText
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    private lateinit var btnShowLocation: Button
    private lateinit var textLocation: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnSend = findViewById(R.id.buttonSend)
        phoneNumberEditText = findViewById(R.id.phoneNumber)
        btnShowLocation = findViewById(R.id.ShowLocation)
        textLocation = findViewById(R.id.location)
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)
        btnShowLocation.setOnClickListener {
            checkGPSPermissions()
        }
        btnSend.setOnClickListener {
            val phoneNumberText = phoneNumberEditText.text.toString()
            messageSMS =  "The user's location is: \n " + textLocation.text.toString()
            try {
                checkSMS(phoneNumberText, messageSMS)
                Toast.makeText(applicationContext, "Mensaje enviado", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(
                    applicationContext,
                    "Error al enviar el mensaje" + " " + e.message.toString(),
                    Toast.LENGTH_LONG
                ).show()
            }

        }

    }

    private fun checkGPSPermissions() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                1
            )
        } else {
            getLocations()
        }
    }

    private fun checkSMS(cellNumber: String, message: String) {
        val smsManager: SmsManager
        smsManager = SmsManager.getDefault()
        smsManager.sendTextMessage(cellNumber, null, message, null, null)
    }

    @SuppressLint("MissingPermission")
    private fun getLocations() {
        fusedLocationProviderClient.lastLocation?.addOnSuccessListener {
            if (it == null) {
                Toast.makeText(this, "Sorry can't get location", Toast.LENGTH_SHORT).show()
            } else it.apply {
                val time = it.time
                val latitude = it.latitude
                val longitude = it.longitude
                textLocation.text = "Latitude: $latitude \nLongitude: $longitude\nTime Stamp: $time"
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    ) == PackageManager.PERMISSION_GRANTED
                ) {
                    Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show()
                    getLocations()
                } else {
                    Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

}